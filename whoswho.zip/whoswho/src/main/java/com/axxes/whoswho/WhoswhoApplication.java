package com.axxes.whoswho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhoswhoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhoswhoApplication.class, args);
	}
}
