package com.axxes.whoswho.model;

public enum Sex {
    MALE, FEMALE
}
