package com.axxes.whoswho.service.impl;

import com.axxes.whoswho.model.Person;
import com.axxes.whoswho.model.Round;
import com.axxes.whoswho.model.Sex;
import com.axxes.whoswho.repository.PersonRepository;
import com.axxes.whoswho.service.RoundService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.fail;

@RunWith(SpringRunner.class)
@SpringBootTest
class RoundServiceImplTest {

    private Person personPlaying;

    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private RoundService roundService;

    @BeforeEach
    void setUp() {
        personPlaying = new Person("Benjamin", "Goesaert", "", Sex.MALE);

        personRepository.save(personPlaying);
        personRepository.save(new Person("Freddy", "De Vadder", "", Sex.MALE));
        personRepository.save(new Person("Kevin", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Marloes", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Maarten", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Mathijs", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Mats", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Charlien", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Stef", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Elize", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Benjamin", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Jonas", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Jelle", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Bram", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Andrea", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Jan", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Tom", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Lieven", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Shauni", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Fien", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Arne", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Julie", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Jorgi", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Thomas", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Greogory", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Shanah", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Lode", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Zento", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Kevin", "Goesaert", "", Sex.MALE));
        personRepository.save(new Person("Sarah", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Jana", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Kaat", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Marieke", "Goesaert", "", Sex.FEMALE));
        personRepository.save(new Person("Vicky", "Goesaert", "", Sex.FEMALE));

    }

    @Test
    void getRounds() {

    }

    @Test
    void PersonPlayingDoesNotExistInRound() {
        setUp();
        List<Round> rounds = roundService.getRounds(personPlaying);


        rounds.forEach(round -> {
            round.getPersons().forEach(person -> {
                if (person.getId() == personPlaying.getId()) {
                    fail("Person playing is present in rounds");
                }
            });
        });
    }
}